# Example Package



This is a simple example package for exercise.


The package function is simple calculator operations +,-,*,/





You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

