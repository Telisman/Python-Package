def add_nnumbers(num1,num2):
    return num1 + num2

def subtract_nnumbers(num1,num2):
    return num1 - num2

def multply_nnumbers(num1,num2):
    return num1 * num2

def divide_nnumbers(num1,num2):
    return num1 / num2